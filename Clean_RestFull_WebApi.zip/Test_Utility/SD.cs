﻿namespace Test_Utility
{
    public static class SD 
    {
        public enum ApiType
        {
            GET,
            POST,
            PATCH,
            DELETE,
            PUT

        } 
    }
}
