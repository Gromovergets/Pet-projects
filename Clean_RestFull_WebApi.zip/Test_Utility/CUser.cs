﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_Utility
{
    public class CUser
    {
        public static bool Log { get; set; }
        public static WebApplication1.Models.User user { get; set; }
    }
}
