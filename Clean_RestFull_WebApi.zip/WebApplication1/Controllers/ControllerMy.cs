﻿using Microsoft.AspNetCore.Mvc;
using System.Net;
using WebApplication1.Models;

//using WebApplication1.Models;
using WebApplication1.Repository;

namespace WebApplication1.Controllers
{
    [Route("api/TestAPI")]
    [ApiController]
    public class MyController : ControllerBase
    {
        protected APIResponse _response;
        private readonly IUserrepository _repos;
        public MyController(IUserrepository irep)
        {
            _response = new APIResponse();
            _repos = irep;
        }

        [HttpGet(Name = "GetAllUsers")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        public async Task<ActionResult<APIResponse>> GetHotels()
        {
            try
            {
                _response.Result = await _repos.GetAll();
                _response.Code = HttpStatusCode.OK;
                return Ok(_response);

            }
            catch (Exception ex)
            {
                _response.IsSuccess = false;
                _response.Code = HttpStatusCode.BadRequest;
                _response.Errors = new List<string> { ex.ToString() };
            }
            return _response;

        }




    }
}
