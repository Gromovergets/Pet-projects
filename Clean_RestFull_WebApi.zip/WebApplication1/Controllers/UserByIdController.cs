﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using WebApplication1.Models;
using WebApplication1.Repository;

namespace WebApplication1.Controllers
{
    [Route("api/TestAPI")]
    [ApiController]
    public class UserByIdController : ControllerBase
    {
        protected APIResponse _response;
        private readonly IUserrepository irep;
        public UserByIdController(IUserrepository repos)
        {
            _response=new APIResponse();
            irep = repos;
        }

        [HttpGet("{id:int}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public async Task<ActionResult<APIResponse>> GeTUserById(int id)
        {
            try
            {

                var user = await irep.Get(u=>u.IdUser==id,tracking:false);
                _response.Result = user;
                _response.Code = HttpStatusCode.OK;
                return Ok(_response);
            }
            catch (Exception ex)
            {
                _response.Code=HttpStatusCode.BadRequest;
                _response.IsSuccess = false;
   
                _response.Errors = new List<string> { ex.ToString() };
            }
            return _response;


        }
        [HttpPost]

        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        [ProducesResponseType(StatusCodes.Status200OK)]
        public async Task<ActionResult<APIResponse>> PostUser(User user)
        {
            try
            {
                
                await irep.CreateUser(user);
                _response.Result = user;
                _response.Code = HttpStatusCode.OK;
                return Ok(_response);
            }
            catch(Exception ex)
            {
                _response.Code=HttpStatusCode.BadRequest;
                _response.IsSuccess=false;
                _response.Errors=new List<string> { ex.ToString() };
            }
            return _response;
            



        }
       






    }
}
