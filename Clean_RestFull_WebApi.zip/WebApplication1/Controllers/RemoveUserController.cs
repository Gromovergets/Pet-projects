﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using WebApplication1.Models;
using WebApplication1.Repository;

namespace WebApplication1.Controllers
{
    [Route("api/TestAPI")]
    [ApiController]
    public class RemoveUserController : ControllerBase
    {
        private IUserrepository _irep;
        protected APIResponse _response;

        public RemoveUserController(IUserrepository irep)
        {
            _response = new APIResponse();  
            _irep = irep;
        }
        [HttpDelete("{id:int}", Name = "Removeuser")]
        [ProducesResponseType(StatusCodes.Status404NotFound)]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        public async Task<ActionResult<APIResponse>> DelUser(int id)
        {
            try
            {
                var user = await _irep.Get(x => x.IdUser == id,tracking:false); 
                await _irep.RemoverUser(user);
                _response.Code = HttpStatusCode.NoContent;
                return Ok(_response);
            }
            catch (Exception ex)
            {
                _response.Code = HttpStatusCode.BadRequest;
                _response.IsSuccess = false;
                _response.Errors = new List<string> { ex.ToString() };
            }

            return _response;
        }
    }
}
