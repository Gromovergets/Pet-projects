﻿using Azure;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using WebApplication1.Models;
using WebApplication1.Repository;

namespace WebApplication1.Controllers
{
    [Route("api/TestAPI")]
    [ApiController]
    public class UptudeUserController : ControllerBase
    {
        protected APIResponse _response;
        private IUserrepository _irep;

        public UptudeUserController(IUserrepository irep)
        {
            _response = new APIResponse();
            _irep = irep;
        }
        [HttpPut]
        [ProducesResponseType(StatusCodes.Status204NoContent)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public async Task<ActionResult<APIResponse>> UptadeUser(User user)
        {
            try
            {
               
                 await _irep.UptadeUser(user);
                _response.Code = HttpStatusCode.OK;
                _response.Result = user;

            }
            catch(Exception ex)
            {
                _response.IsSuccess = false;
                _response.Code=HttpStatusCode.BadRequest;
                _response.Errors = new List<string> { ex.ToString() };
            }

            return _response;

        }

        
    }
}
