﻿using Azure;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using WebApplication1.Models;
using WebApplication1.Repository;

namespace WebApplication1.Controllers
{

    [Route("api/UserAR")]
    [ApiController]
    public class UserController : Controller
    {

        protected APIResponse _response;
        private readonly IUserrepository _irep;
        public UserController(IUserrepository repos)
        {
            _response = new APIResponse();
            _irep = repos;
        }




        [HttpPost("login")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public async Task<ActionResult<APIResponse>> LoginU([FromBody]UserAuth user)
        {
            try
            {
                User u = await _irep.loginUser(user);

                _response.Result = u;
                _response.Code = HttpStatusCode.OK;
                return Ok(_response);


            }
            catch (Exception ex)
            {
                _response.Code = HttpStatusCode.BadRequest;
                _response.IsSuccess = false;

                _response.Errors = new List<string> { ex.ToString() };
            }
            return _response;


        }
        [HttpPost("register")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]

        public async Task<ActionResult<APIResponse>> RegisterU([FromBody] UserReg user)
        {
            try
            {
                User u = new User();
                u.Login = user.login;
                u.Password = user.password;
                u.NamePosition = user.role;
                await _irep.CreateUser(u);
                _response.Result = u;
                _response.Code = HttpStatusCode.OK;
                return Ok(_response);
            }
            catch (Exception ex)
            {
                _response.Code = HttpStatusCode.BadRequest;
                _response.IsSuccess = false;

                _response.Errors = new List<string> { ex.ToString() };
            }
            return _response;


        }

    }
}
