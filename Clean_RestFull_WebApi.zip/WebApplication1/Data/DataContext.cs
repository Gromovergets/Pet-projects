﻿//using Microsoft.EntityFrameworkCore;
//using WebApplication1.Models;


//namespace WebApplication1.Data
//{
//    public  class DataContext
//    {
//        private static LabContext lab;
//        public static LabContext DataContexted()
//        {
//            if (lab == null)
//            {
//                lab= new LabContext();
//            }
//            return lab;
//        }
        

//    }
//}
