﻿using System;
using System.Collections.Generic;

namespace WebApplication1.Models;

public partial class Order
{
    public int IdOrder { get; set; }

    public DateTime? DateCreate { get; set; }

    public string? StatusOrder { get; set; }

    public DateTime? DatePerfoming { get; set; }

    public int IdCustomer { get; set; }

    public int? IdOrdered { get; set; }

    public string? CodeMatirial { get; set; }

    public virtual User IdCustomer1 { get; set; } = null!;

    public virtual Customer IdCustomerNavigation { get; set; } = null!;

    public virtual ICollection<Ordered> Ordereds { get; set; } = new List<Ordered>();
}
