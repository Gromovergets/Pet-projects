﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication1.Models
{
    public class UserReg
    {
        [Required]
        public string login { get; set; }
        [Required]
        public string password { get; set; }
        [Required]
        public string role { get; set; }

    }
}
