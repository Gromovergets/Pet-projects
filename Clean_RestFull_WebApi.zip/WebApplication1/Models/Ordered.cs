﻿using System;
using System.Collections.Generic;

namespace WebApplication1.Models;

public partial class Ordered
{
    public int IdOrderService { get; set; }

    public string? ServiceStatus { get; set; }

    public int? IdAnalyzer { get; set; }

    public int? IdLaborant { get; set; }

    public int IdOrder { get; set; }

    public DateTime? TimePerfoming { get; set; }

    public int IdOrdered { get; set; }

    public string? Conclusion { get; set; }

    public virtual Analyzer? IdAnalyzerNavigation { get; set; }

    public virtual User? IdLaborantNavigation { get; set; }

    public virtual Order IdOrderNavigation { get; set; } = null!;

    public virtual Service IdOrderServiceNavigation { get; set; } = null!;
}
