﻿using System;
using System.Collections.Generic;

namespace WebApplication1.Models;

public partial class User
{
    public int IdUser { get; set; }

    public string Login { get; set; } = null!;

    public string Password { get; set; } = null!;

    public string? NamePosition { get; set; }

    public int? IdPosition { get; set; }

    public virtual Assistian? Assistian { get; set; }

    public virtual Customer? Customer { get; set; }

    public virtual ICollection<Ordered> Ordereds { get; set; } = new List<Ordered>();

    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
}
