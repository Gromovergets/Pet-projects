﻿using System;
using System.Collections.Generic;

namespace WebApplication1.Models;

public partial class Analyzer
{
    public int IdAnalyzer { get; set; }

    public DateTime? DateCreate { get; set; }

    public DateTime? DateFinish { get; set; }

    public virtual ICollection<Ordered> Ordereds { get; set; } = new List<Ordered>();
}
