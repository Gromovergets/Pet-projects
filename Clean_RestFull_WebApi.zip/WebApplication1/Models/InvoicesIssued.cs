﻿using System;
using System.Collections.Generic;

namespace WebApplication1.Models;

public partial class InvoicesIssued
{
    public int IdUserLikeAccountans { get; set; }

    public int IdUserLikeCustomer { get; set; }

    public int IdOrder { get; set; }

    public int IdAccount { get; set; }
}
