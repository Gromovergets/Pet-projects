﻿using System;
using System.Collections.Generic;

namespace WebApplication1.Models;

public partial class DateEntrance
{
    public int? IdUser { get; set; }

    public DateTime? DateLast { get; set; }

    public string? LoginUser { get; set; }

    public string? Truelogin { get; set; }

    public int IdEntrance { get; set; }
}
