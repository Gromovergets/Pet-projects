﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace WebApplication1.Models;

public partial class LabContext : DbContext
{
    public LabContext()
    {
    }

    public LabContext(DbContextOptions<LabContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Accountant> Accountants { get; set; }

    public virtual DbSet<Analyzer> Analyzers { get; set; }

    public virtual DbSet<Assistian> Assistians { get; set; }

    public virtual DbSet<Customer> Customers { get; set; }

    public virtual DbSet<DateEntrance> DateEntrances { get; set; }

    public virtual DbSet<InsuranceCompany> InsuranceCompanies { get; set; }

    public virtual DbSet<InvoicesIssued> InvoicesIssueds { get; set; }

    public virtual DbSet<Order> Orders { get; set; }

    public virtual DbSet<Ordered> Ordereds { get; set; }

    public virtual DbSet<Service> Services { get; set; }

    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=LAPTOP-KLBSCP3I\\SQLEXPRESS;Initial Catalog=Lab;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=True;Application Intent=ReadWrite;Multi Subnet Failover=False");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Accountant>(entity =>
        {
            entity.HasKey(e => e.IdPosition);

            entity.Property(e => e.IdPosition).HasColumnName("id_position");
            entity.Property(e => e.FullName)
                .HasMaxLength(50)
                .HasColumnName("full_name");
            entity.Property(e => e.IdRkAccount).HasColumnName("id_rk_account");
        });

        modelBuilder.Entity<Analyzer>(entity =>
        {
            entity.HasKey(e => e.IdAnalyzer);

            entity.Property(e => e.IdAnalyzer).HasColumnName("id_analyzer");
            entity.Property(e => e.DateCreate)
                .HasColumnType("datetime")
                .HasColumnName("date_create");
            entity.Property(e => e.DateFinish)
                .HasColumnType("datetime")
                .HasColumnName("date_finish");
        });

        modelBuilder.Entity<Assistian>(entity =>
        {
            entity.HasKey(e => e.IdAssistiant).HasName("PK_Assistians_1");

            entity.Property(e => e.IdAssistiant)
                .ValueGeneratedNever()
                .HasColumnName("id_assistiant");
            entity.Property(e => e.FullName)
                .HasMaxLength(50)
                .HasColumnName("full_name");

            entity.HasOne(d => d.IdAssistiantNavigation).WithOne(p => p.Assistian)
                .HasForeignKey<Assistian>(d => d.IdAssistiant)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Assistians_Users1");
        });

        modelBuilder.Entity<Customer>(entity =>
        {
            entity.HasKey(e => e.IdCustomer).HasName("PK_Customers_1");

            entity.Property(e => e.IdCustomer)
                .ValueGeneratedOnAdd()
                .HasColumnName("id_customer");
            entity.Property(e => e.DateBorn)
                .HasColumnType("datetime")
                .HasColumnName("date_born");
            entity.Property(e => e.EmailCustomer)
                .HasMaxLength(30)
                .HasColumnName("email_customer");
            entity.Property(e => e.FullName)
                .HasMaxLength(30)
                .HasColumnName("full_name");
            entity.Property(e => e.IdInsuranceCompany).HasColumnName("id_insurance_company");
            entity.Property(e => e.Passport)
                .HasMaxLength(30)
                .HasColumnName("passport");
            entity.Property(e => e.Policy)
                .HasMaxLength(30)
                .HasColumnName("policy");
            entity.Property(e => e.TelephoneNumber)
                .HasMaxLength(30)
                .HasColumnName("telephone_number");
            entity.Property(e => e.TypePolicy)
                .HasMaxLength(10)
                .HasColumnName("type_policy");

            entity.HasOne(d => d.IdCustomerNavigation).WithOne(p => p.Customer)
                .HasForeignKey<Customer>(d => d.IdCustomer)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Customers_Users");

            entity.HasOne(d => d.IdInsuranceCompanyNavigation).WithMany(p => p.Customers)
                .HasForeignKey(d => d.IdInsuranceCompany)
                .HasConstraintName("FK_Customers_InsuranceCompany");
        });

        modelBuilder.Entity<DateEntrance>(entity =>
        {
            entity.HasKey(e => e.IdEntrance);

            entity.ToTable("date_entrance");

            entity.Property(e => e.IdEntrance).HasColumnName("id_entrance");
            entity.Property(e => e.DateLast)
                .HasColumnType("datetime")
                .HasColumnName("date_last");
            entity.Property(e => e.IdUser).HasColumnName("id_user");
            entity.Property(e => e.LoginUser)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("login_user");
            entity.Property(e => e.Truelogin)
                .HasMaxLength(40)
                .HasColumnName("truelogin");
        });

        modelBuilder.Entity<InsuranceCompany>(entity =>
        {
            entity.HasKey(e => e.IdInsuranceCompany);

            entity.ToTable("InsuranceCompany");

            entity.Property(e => e.IdInsuranceCompany).HasColumnName("id_insurance_company");
            entity.Property(e => e.Adres)
                .HasMaxLength(50)
                .IsFixedLength()
                .HasColumnName("adres");
            entity.Property(e => e.Bik).HasMaxLength(30);
            entity.Property(e => e.Inn)
                .HasMaxLength(30)
                .HasColumnName("inn");
            entity.Property(e => e.NameCompany)
                .HasMaxLength(30)
                .HasColumnName("name_company");
            entity.Property(e => e.PaymentAccount)
                .HasMaxLength(30)
                .HasColumnName("payment_account");
        });

        modelBuilder.Entity<InvoicesIssued>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("Invoices_Issued");

            entity.Property(e => e.IdAccount)
                .ValueGeneratedOnAdd()
                .HasColumnName("id_account");
            entity.Property(e => e.IdOrder).HasColumnName("id_order");
            entity.Property(e => e.IdUserLikeAccountans).HasColumnName("id_user_like_accountans");
            entity.Property(e => e.IdUserLikeCustomer).HasColumnName("id_user_like_customer");
        });

        modelBuilder.Entity<Order>(entity =>
        {
            entity.HasKey(e => e.IdOrder);

            entity.ToTable("Order");

            entity.Property(e => e.IdOrder).HasColumnName("Id_order");
            entity.Property(e => e.CodeMatirial)
                .HasMaxLength(20)
                .IsFixedLength()
                .HasColumnName("code_matirial");
            entity.Property(e => e.DateCreate)
                .HasColumnType("datetime")
                .HasColumnName("date_create");
            entity.Property(e => e.DatePerfoming)
                .HasColumnType("datetime")
                .HasColumnName("date_perfoming");
            entity.Property(e => e.IdCustomer).HasColumnName("id_customer");
            entity.Property(e => e.IdOrdered).HasColumnName("id_ordered");
            entity.Property(e => e.StatusOrder)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("status_order");

            entity.HasOne(d => d.IdCustomerNavigation).WithMany(p => p.Orders)
                .HasForeignKey(d => d.IdCustomer)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Order_Customers");

            entity.HasOne(d => d.IdCustomer1).WithMany(p => p.Orders)
                .HasForeignKey(d => d.IdCustomer)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Order_Users1");
        });

        modelBuilder.Entity<Ordered>(entity =>
        {
            entity.HasKey(e => e.IdOrdered);

            entity.ToTable("Ordered");

            entity.Property(e => e.IdOrdered).HasColumnName("id_ordered");
            entity.Property(e => e.Conclusion).HasMaxLength(130);
            entity.Property(e => e.IdAnalyzer).HasColumnName("id_analyzer");
            entity.Property(e => e.IdLaborant).HasColumnName("id_laborant");
            entity.Property(e => e.IdOrder).HasColumnName("id_order");
            entity.Property(e => e.IdOrderService).HasColumnName("id_order_service");
            entity.Property(e => e.ServiceStatus)
                .HasMaxLength(10)
                .HasColumnName("service_status");
            entity.Property(e => e.TimePerfoming)
                .HasColumnType("datetime")
                .HasColumnName("time_perfoming");

            entity.HasOne(d => d.IdAnalyzerNavigation).WithMany(p => p.Ordereds)
                .HasForeignKey(d => d.IdAnalyzer)
                .HasConstraintName("FK_Ordered_Analyzers");

            entity.HasOne(d => d.IdLaborantNavigation).WithMany(p => p.Ordereds)
                .HasForeignKey(d => d.IdLaborant)
                .HasConstraintName("FK_Ordered_Users");

            entity.HasOne(d => d.IdOrderNavigation).WithMany(p => p.Ordereds)
                .HasForeignKey(d => d.IdOrder)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Ordered_Order");

            entity.HasOne(d => d.IdOrderServiceNavigation).WithMany(p => p.Ordereds)
                .HasForeignKey(d => d.IdOrderService)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Ordered_Services");
        });

        modelBuilder.Entity<Service>(entity =>
        {
            entity.HasKey(e => e.IdService);

            entity.Property(e => e.IdService)
                .ValueGeneratedNever()
                .HasColumnName("id-service");
            entity.Property(e => e.AverageDeviation).HasColumnName("average_deviation");
            entity.Property(e => e.CostOfService).HasColumnName("cost_of_service");
            entity.Property(e => e.IdAssistiant).HasColumnName("id_assistiant");
            entity.Property(e => e.NameService)
                .HasMaxLength(30)
                .IsFixedLength()
                .HasColumnName("name_service");
            entity.Property(e => e.TimePerfoming)
                .HasColumnType("datetime")
                .HasColumnName("time_perfoming");

            entity.HasOne(d => d.IdAssistiantNavigation).WithMany(p => p.Services)
                .HasForeignKey(d => d.IdAssistiant)
                .HasConstraintName("FK_Services_Assistians");
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(e => e.IdUser).HasName("PK_Users_1");

            entity.Property(e => e.IdUser).HasColumnName("id_user");
            entity.Property(e => e.IdPosition).HasColumnName("id_position");
            entity.Property(e => e.Login)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("login");
            entity.Property(e => e.NamePosition)
                .HasMaxLength(20)
                .HasColumnName("name_position");
            entity.Property(e => e.Password)
                .HasMaxLength(10)
                .IsFixedLength()
                .HasColumnName("password");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
