﻿using System;
using System.Collections.Generic;

namespace WebApplication1.Models;

public partial class Assistian
{
    public int IdAssistiant { get; set; }

    public string? FullName { get; set; }

    public virtual User IdAssistiantNavigation { get; set; } = null!;

    public virtual ICollection<Service> Services { get; set; } = new List<Service>();
}
