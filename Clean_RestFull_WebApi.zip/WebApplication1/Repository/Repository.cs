﻿
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;
using WebApplication1.Models;

namespace WebApplication1.Repository
{
    public class Repository<T> : Irepository<T> where T : class
    {
        private readonly LabContext _context;
        internal DbSet<T> _set;
        public Repository(LabContext lab) 
        { 
            _context = lab;
            _set = _context.Set<T>();

        }
        public async Task CreateUser(T entity)
        {
            await _set.AddAsync(entity);
            await Save();

        }

        public async Task<T> Get(Expression<Func<T,bool>> filter=null, bool tracking = true,string? incl=null)
        {
            IQueryable<T> query=_set;
         
            if (tracking == false)
            {
                query = query.AsNoTracking();
            }
            if (filter != null)
            {
                query = query.Where(filter);
            }
            
                
            query = query.Include("Assistian");
            
            return await query.FirstOrDefaultAsync();
        }

        public async Task<ICollection<T>> GetAll()
        {
           return await _set.ToListAsync();
        }

        public async Task RemoverUser(T entity)
        {
            _set.Remove(entity);
            await Save();
        }
                

        public async Task Save()
        {
            await _context.SaveChangesAsync();
        }

        
    }
}
