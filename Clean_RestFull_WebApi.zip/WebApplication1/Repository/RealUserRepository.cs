﻿using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

using WebApplication1.Models;
//using WebApplication1.Models;
//using WebApplication1.Models;

namespace WebApplication1.Repository
{
    public class RealUserRepository :Repository<User>, IUserrepository
    {
        private readonly LabContext _context;

        public RealUserRepository(LabContext context):base(context)
        {

            _context = context;
            //_context.Users.Include(x=>x.Assistian).ToList();
            
        }

        public async Task<User> loginUser(UserAuth user)
        {
            User us = await _context.Users.FirstOrDefaultAsync(x => x.Login.Trim() == user.login);
            if (us != null)
            {
                if (us.Password.Trim() == user.password)
                {
                    return us;
                }

            }
            return null;
            
        }

        public async Task UptadeUser(User user)
        {
           
            _context.Users.Update(user);
            await Save();
        }

        
    }
}
