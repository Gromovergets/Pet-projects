﻿

using System.Linq.Expressions;
using WebApplication1.Models;

namespace WebApplication1.Repository
{
    public interface IUserrepository:Irepository<User>
    {
         Task UptadeUser(User user);
         Task<User> loginUser(UserAuth user);


    }
}
