﻿using System.Linq.Expressions;
using WebApplication1.Models;

namespace WebApplication1.Repository
{
    public interface Irepository<T> where T : class
    {
        Task<ICollection<T>> GetAll();
        Task<T> Get(Expression<Func<T, bool>>? filter = null, bool tracking = true,string? includep=null);
        Task CreateUser(T entity);
        Task RemoverUser(T entity);
        Task Save();
    }
}
