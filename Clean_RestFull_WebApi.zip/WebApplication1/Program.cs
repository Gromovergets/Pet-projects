using Microsoft.EntityFrameworkCore;
using System;
using System.Text.RegularExpressions;
using WebApplication1;

using WebApplication1.Models;

//using WebApplication1.Models;
using WebApplication1.Repository;


var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddRazorPages();
builder.Services.AddControllers();
builder.Services.AddSwaggerGen();

builder.Services.AddControllersWithViews()
    .AddNewtonsoftJson(options =>
    options.SerializerSettings.ReferenceLoopHandling = Newtonsoft.Json.ReferenceLoopHandling.Ignore
);

builder.Services.AddDbContext<LabContext>(options =>
{
    options.UseSqlServer("Server=LAPTOP-KLBSCP3I\\SQLEXPRESS;Initial Catalog=Lab;Integrated Security=False;Encrypt=False;Trusted_Connection=True");
});
//builder.Services.AddScoped <Irepository,Repository>();
builder.Services.AddScoped<IUserrepository, RealUserRepository>();



var app = builder.Build();


if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
   
}
app.UseSwaggerUI(options =>
{
    options.SwaggerEndpoint("/swagger/v1/swagger.json", "v1");
    options.RoutePrefix = string.Empty;
});

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapRazorPages();
app.MapControllerRoute(name: "default", pattern: "{controller}/{action}");
app.MapControllerRoute(name: "UserAR", pattern: "{controller}/{action}" );

//app.MapGet("/", (LabContext lb) => lb.Users.ToList());

app.Run();


