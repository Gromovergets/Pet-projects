﻿using System;
using System.Collections.Generic;

namespace TestView.Models;

public partial class InsuranceCompany
{
    public int IdInsuranceCompany { get; set; }

    public string NameCompany { get; set; } = null!;

    public string Adres { get; set; } = null!;

    public string Inn { get; set; } = null!;

    public string PaymentAccount { get; set; } = null!;

    public string Bik { get; set; } = null!;

    public virtual ICollection<Customer> Customers { get; set; } = new List<Customer>();
}
