﻿using static Test_Utility.SD;

namespace TestView.Models
{
    public class Request
    {
        public ApiType Type { get; set; } = ApiType.GET;
        public string Url;
        public object Data;
    }
}
