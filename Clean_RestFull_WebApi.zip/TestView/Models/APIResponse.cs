﻿using System.Net;

namespace TestView.Models
{
    public class APIResponse
    {
        public HttpStatusCode Code { get; set; }
        public Boolean IsSuccess { get; set; } = true;
        public List<string> Errors { get; set; }
        public Object Result { get; set; }
    }
}
