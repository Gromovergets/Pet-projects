﻿using System;
using System.Collections.Generic;

namespace TestView.Models;

public partial class Service
{
    public int IdService { get; set; }

    public string? NameService { get; set; }

    public double? CostOfService { get; set; }

    public DateTime? TimePerfoming { get; set; }

    public double? AverageDeviation { get; set; }

    public int? IdAssistiant { get; set; }

    public virtual Assistian? IdAssistiantNavigation { get; set; }

    public virtual ICollection<Ordered> Ordereds { get; set; } = new List<Ordered>();
}
