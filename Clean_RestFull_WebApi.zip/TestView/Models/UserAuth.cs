﻿using System.ComponentModel.DataAnnotations;

namespace TestView.Models
{
    public class UserAuth
    {
        [Required]
        public string login { get; set; }
        [Required]
        public string password { get; set; }

    }
}
