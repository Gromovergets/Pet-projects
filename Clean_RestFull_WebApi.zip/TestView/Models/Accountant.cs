﻿using System;
using System.Collections.Generic;

namespace TestView.Models;

public partial class Accountant
{
    public string? FullName { get; set; }

    public int? IdRkAccount { get; set; }

    public int IdPosition { get; set; }
}
