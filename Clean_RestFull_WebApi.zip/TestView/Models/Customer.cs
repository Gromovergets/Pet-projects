﻿using System;
using System.Collections.Generic;

namespace TestView.Models;

public partial class Customer
{
    public string? FullName { get; set; }

    public DateTime? DateBorn { get; set; }

    public string? Passport { get; set; }

    public string? TelephoneNumber { get; set; }

    public string? EmailCustomer { get; set; }

    public string? Policy { get; set; }

    public string? TypePolicy { get; set; }

    public int? IdInsuranceCompany { get; set; }

    public int IdCustomer { get; set; }

    public virtual User IdCustomerNavigation { get; set; } = null!;

    public virtual InsuranceCompany? IdInsuranceCompanyNavigation { get; set; }

    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();
}
