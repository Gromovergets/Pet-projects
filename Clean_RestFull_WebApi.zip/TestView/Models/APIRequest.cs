﻿using static Test_Utility.SD;

namespace TestView.Models
{
    public class APIRequest
    {
        public ApiType apiType { get; set; } = ApiType.GET;
        public string Url;
        public object Data;
    }
}
