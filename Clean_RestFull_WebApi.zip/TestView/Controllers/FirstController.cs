﻿using Azure;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Reflection;
using TestView.Models;
using TestView.Services.IService;
using WebApplication1.Models;
using APIResponse = TestView.Models.APIResponse;
using User = TestView.Models.User;

namespace TestView.Controllers
{
    public class FirstController : Controller
    {
        public readonly IMyService ser;
        public  FirstController(IMyService service)
        {
           ser=service;
        }
        [HttpGet("GetAll")]
        public async Task<IActionResult> GetAllIndex()
        {
             List<User> list=new();
            var response = await ser.GetAllAsync<APIResponse>();
            if(response != null&&response.IsSuccess) 
            {
                list=JsonConvert.DeserializeObject<List<User>>(Convert.ToString(response.Result));
            }
            return View(list);
        }
        public async Task<IActionResult> CreateIndex() 
        {
            var user = new User();
            return View(user);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateUser(User user)
        {
            if (ModelState.IsValid)
            {
                TempData["sucsess"] = "Пользователь успешно создан";
                var response = await ser.CreateAsync<APIResponse>(user);
                if (response != null && response.IsSuccess)
                {
                    return RedirectToAction(nameof(GetAllIndex));
                }
            }
            TempData["Eror"] = "Неизвестная ошибка";
            return View(user);
            
        }
        
        public async Task<IActionResult> UptadeUserIndex(int id)
        {
           var response =await ser.GetAsync<APIResponse>(id);
            if (response != null && response.IsSuccess)
            {
                var user= JsonConvert.DeserializeObject<User>(Convert.ToString(response.Result));
                return View(user);
            }
           
            return RedirectToAction(nameof(GetAllIndex));
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UptadeUserIndex(User user)
        {
            if (ModelState.IsValid)
            {
                 
                var response = await ser.UpdateAsync<APIResponse>(user);
                if (response != null && response.IsSuccess)
                {
                    TempData["sucsess"] = "Пользователь успешно обновлен";
                    return RedirectToAction(nameof(GetAllIndex));
                }
            }
            TempData["Eror"] = "Неизвестная ошибка";
            return View(user);

        }
        public async Task<IActionResult> DeleteUser(int id)
        {
            var response = await ser.GetAsync<APIResponse>(id);
            if (response != null && response.IsSuccess)
            {
                
                var user = JsonConvert.DeserializeObject<User>(Convert.ToString(response.Result));
                return View(user);
            }

           
            return RedirectToAction(nameof(GetAllIndex));
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteUser(User user)
        {
            
                var response = await ser.RemomeAsync<APIResponse>(user.IdUser);
                if (response != null && response.IsSuccess)
                {
                TempData["sucsess"] = "Пользователь успешно удален";
                return RedirectToAction(nameof(GetAllIndex));
                }
            TempData["Eror"] = "Неизвестная ошибка";
            return View(user);

        }
        public async Task<IActionResult> InfoUser(int id)
        {
            var response = await ser.GetAsync<APIResponse>(id);
            if (response != null && response.IsSuccess)
            {
                var user=JsonConvert.DeserializeObject<User>(Convert.ToString(response.Result));
               
                return View(user);
               
            }

            return RedirectToAction(nameof(GetAllIndex));
        }
        public async Task<IActionResult> OnlyUsers()
        {
            var response = await ser.GetAllAsync<APIResponse>();

            if (response != null && response.IsSuccess)
            {
                var users = JsonConvert.DeserializeObject<List<User>>(Convert.ToString(response.Result));
                List<User>list= new List<User>();
                users.ForEach(x => { if (x.NamePosition.Trim() == "Пользователь") list.Add(x); });

                return View(list);

            }

            return RedirectToAction(nameof(HomeController.Index));
        }
        

    }
}
