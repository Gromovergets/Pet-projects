﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Collections.Generic;
using Test_Utility;
using TestView.Models;
using TestView.Services.IService;


namespace TestView.Controllers
{
    public class LoginController : Controller
    {
        public readonly IMyService ser;
        public LoginController(IMyService service)
        {
            ser = service;
        }
        [HttpGet("ErorLogin")]
        public async Task<IActionResult> ErorLogin()
        {

            return View();
        }
        [HttpGet]
        public async Task<IActionResult> Autorezetion() 
        {
            var user = new UserAuth();
            return View(user);
        }
       
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Autorezetion(UserAuth user)
        {
            if (ModelState.IsValid)
            {
                var response = await ser.Login<APIResponse>(user);
               
                if (response.Result!= null && response.IsSuccess)
                {
                    TempData["sucsess"] = "Пользователь успешно авторизован";
                    CUser.Log=true;
                    return RedirectToAction("GetAllIndex","First");
                }
               
            }
            TempData["Eror"] = "Неизвестная ошибка";
            return RedirectToAction("ErorLogin");


        }
        public async Task<IActionResult> Regestration()
        {
            var user = new UserReg();
            return View(user);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Regestration(UserReg user)
        {
            if (ModelState.IsValid)
            {
                User u = new User();
                u.Login = user.login;
                u.Password = user.password;
                u.NamePosition = user.role;
               
              
                    var response = new APIResponse();
                    response.Result = await ser.Register<UserReg>(user);
                    if (response.Result != null && response.IsSuccess)
                    {
                        TempData["sucsess"] = "Пользователь успешно зарегистрирован";
                        return RedirectToAction(nameof(Autorezetion));
                    }
                
               

            }
            TempData["Eror"] = "Неизвестная ошибка";
            return RedirectToAction(nameof(Regestration));


        }
        [HttpGet]
        public async Task<IActionResult> LogOut() 
        {
            return View();
        }
        
        public async  Task<IActionResult> Leave()
        {
            CUser.Log = false;
            return RedirectToAction(nameof(Autorezetion));            
        }



    }
}
