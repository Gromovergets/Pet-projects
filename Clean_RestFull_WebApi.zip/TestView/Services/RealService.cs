﻿using Microsoft.AspNetCore.Mvc;
using Test_Utility;
using TestView.Models;
using TestView.Services.IService;
using WebApplication1.Models;
using User = TestView.Models.User;

namespace TestView.Services
{
    public class RealService : BaseService, IMyService
    {
        public readonly IHttpClientFactory client;
        private string _url;
        public RealService(IHttpClientFactory httpcl,IConfiguration config) : base(httpcl)
        {
            client = httpcl;
            _url = config.GetValue<string>("ServicesUrls:ViewApi");


        }

        public async Task<T> CreateAsync<T>(User user)
        {
            return await Sendasync<T>(new APIRequest
            {
                apiType = SD.ApiType.POST,
                Data = user,
                Url = _url + "/api/TestAPI"

            }) ;
        }

        public async Task<T> GetAllAsync<T>()
        {
            return await Sendasync<T>(new APIRequest{
                apiType = SD.ApiType.GET,
                Url = _url+ "/api/TestAPI"

            });
        }

        public async Task<T> GetAsync<T>(int id)
        {
            string url = _url + "/api/TestAPI/" + id.ToString();
            return await Sendasync<T>(new APIRequest
            {
                apiType = SD.ApiType.GET,
                
                Url = _url + "/api/TestAPI/" + id.ToString()

            }) ;
        }

        public Task<T> RemomeAsync<T>(int id)
        {
            return Sendasync<T>(new APIRequest
            {
                apiType = SD.ApiType.DELETE,
                Url = _url + "/api/TestAPI/"+id.ToString()

            });
        }

        public Task<T> UpdateAsync<T>(User user)
        {
            return Sendasync<T>(new APIRequest
            {
                apiType = SD.ApiType.PUT,
                Data = user,
                Url = _url + "/api/TestAPI"

            });
        }
        public Task<T> Login<T>(Models.UserAuth user)
        {
            return Sendasync<T>(new APIRequest
            {
                apiType = SD.ApiType.POST,
                Data = user,
                Url = _url + "/api/UserAR/login"

            });
        }
        public Task<T> Register<T>(Models.UserReg user)
        {
            return Sendasync<T>(new APIRequest
            {
                apiType = SD.ApiType.POST,
                Data = user,
                Url = _url + "/api/UserAR/register"

            });
        }
    }
}
