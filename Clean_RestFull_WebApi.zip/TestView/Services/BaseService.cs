﻿using Newtonsoft.Json;
using System.Text;
using Test_Utility;
using TestView.Models;
using TestView.Services.IService;

namespace TestView.Services
{
    public class BaseService : IBaseService
    {
        public APIResponse responcemoel { get; set; }
        public IHttpClientFactory httpclient { get; set; }
        public BaseService(IHttpClientFactory httpcl)
        {
            responcemoel = new APIResponse();
            httpclient = httpcl;
        }

        public async Task<T> Sendasync<T>(APIRequest apirequest)
        {
            try
            {


                var client =  httpclient.CreateClient("New Client");
                HttpRequestMessage message = new HttpRequestMessage();
                message.Headers.Add("Accept", "application/json");
                message.RequestUri = new Uri(apirequest.Url);
                if (apirequest.Data != null)
                {
                    message.Content = new StringContent(JsonConvert.SerializeObject(apirequest.Data), Encoding.UTF8, "application/json");
                }
                switch (apirequest.apiType)
                {
                    case SD.ApiType.POST:
                        {
                            message.Method = HttpMethod.Post;
                            break;
                        }
                    case SD.ApiType.PUT:
                        {
                            message.Method = HttpMethod.Put;
                            break;
                        }
                    case SD.ApiType.DELETE:
                        {
                            message.Method = HttpMethod.Delete;
                            break;
                        }
                    default:
                        {
                            message.Method = HttpMethod.Get;
                            break;
                        }
                }
                HttpResponseMessage res = null;
                res = await client.SendAsync(message);
                var content = await res.Content.ReadAsStringAsync();
                var finalResponse = JsonConvert.DeserializeObject<T>(content);
                return finalResponse;


            }
            catch (Exception ex)
            {
                var bad = new APIResponse
                {
                    Errors = new List<string> { ex.ToString() },
                    IsSuccess = false

                };
                var content = JsonConvert.SerializeObject(bad);
                var finalResponse = JsonConvert.DeserializeObject<T>(content);
                return finalResponse;

            }
        }
    }

}
