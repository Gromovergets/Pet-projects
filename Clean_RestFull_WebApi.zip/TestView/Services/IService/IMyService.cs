﻿using User = TestView.Models.User;


namespace TestView.Services.IService
{
    public interface IMyService
    {
        Task<T> GetAllAsync<T>();
        Task<T> GetAsync<T>(int id);
        Task<T> RemomeAsync<T>(int id);
        Task<T> CreateAsync<T>(User user);
        Task<T> UpdateAsync<T>(User user);
        
        Task<T> Login<T>(TestView.Models.UserAuth user);
        Task<T> Register<T>(TestView.Models.UserReg user);

    }
}
