﻿using Microsoft.AspNetCore.Mvc.ApiExplorer;
using TestView.Models;


namespace TestView.Services.IService
{
    public interface IBaseService
    {
        APIResponse responcemoel { get; set; }
        Task<T> Sendasync<T>(APIRequest apirequest);
    }

}
