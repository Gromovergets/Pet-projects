﻿using ServiceDLl.Context;
using ServiceDLl.Models.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Repository
{
    public class ServiceContractRepository
    {
        private ServiceContext _context {  get; set; }
        public ServiceContractRepository() 
        {
            _context = HC.GetC();
        }
        public ServiceContracty[] GetServiceContracties()
        {
            return _context.ServiceContracties.ToArray();
        }
        public void AddServiceContract(ServiceContracty serviceContracty)
        {
            _context.ServiceContracties.Add(serviceContracty);
        }

    }
}
