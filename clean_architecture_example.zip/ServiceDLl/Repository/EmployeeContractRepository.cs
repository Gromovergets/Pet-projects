﻿using ServiceDLl.Context;
using ServiceDLl.Models.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Repository
{
    public  class EmployeeContractRepository
    {
        private ServiceContext _context { get; set; }
        public EmployeeContractRepository()
        {
            _context = HC.GetC();
        }
        public void AddContractEmployee(EmployeeContract emp)
        {
            _context.EmployeeContracts.Add(emp);
        }
        public EmployeeContract[] GetContractEmployees() 
        { 
            return _context.EmployeeContracts.ToArray();    
        }
        public void RemoveEmployee(int id_contract,int id_emp)
        {
            var contract=GetContractEmployees().FirstOrDefault(x=>x.IdContract==id_contract&&x.IdEmployee==id_emp);
            if (contract != null)
            {
                _context.EmployeeContracts.Remove(contract);
            }
            
        }
        public int GetContractByE(int id)
        {
            int k = 0;
            foreach(var el in GetContractEmployees())
            {
                if (el.IdEmployee == id) { 
                k++;}
            }
            return k;
        }
    }
}
