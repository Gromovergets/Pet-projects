﻿using ServiceDLl.Context;
using ServiceDLl.Models.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Repository
{
    public class Repository
    {
        private ServiceContext _context;
        public Repository()
        {
            _context = HC.GetC();
        }
        public void Save()
        {
            try
            {
                _context.SaveChanges();
            }
            catch(Exception ex) { }
                
           
        }
      
    }
}
