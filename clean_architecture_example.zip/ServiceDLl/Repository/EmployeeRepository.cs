﻿using ServiceDLl.Context;
using ServiceDLl.Models.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Repository
{
    public class EmployeeRepository
    {
        private ServiceContext _context;
        public EmployeeRepository()
        {
            _context = HC.GetC();
        }
        public Employee? GetUser(string login, string passsowrd)
        {
            Employee? user = _context.Employees.Where(x => x.Login == login && x.Password == passsowrd).FirstOrDefault();
            if (user != null)
            {
                return user;
            }
            return null;

        }
        public Employee[] GetEmployees()
        {
           return _context.Employees.ToArray();
        }

    }
}
