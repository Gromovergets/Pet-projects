﻿using ServiceDLl.Context;
using ServiceDLl.Models.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Repository
{
    public class EquipmentRepository
    {
        private ServiceContext _context { get; set; }

        public EquipmentRepository()
        {
            _context = HC.GetC();
        }
        public Equipment[] GetEquipments()
        {
           return _context.Equipment.ToArray();
        }
        public Equipment? GetEquipment(int id)
        {
            return _context.Equipment.FirstOrDefault(x=>x.Id==id);
        }
        public EquipmentContract[] GetEquipmentContracts()
        {
            return _context.EquipmentContracts.ToArray();
        }
        public void AddEquipmentContract(int id_contract,int id_equip)
        {
            _context.EquipmentContracts.Add(new EquipmentContract
            {
                IdContract = id_contract,
                IdEquipment = id_equip
            });
        }

    }
}
