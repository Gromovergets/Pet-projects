﻿using ServiceDLl.Context;
using ServiceDLl.Models;
using ServiceDLl.Models.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Repository
{
    public class ClientRepository
    {
        private ServiceContext _context;
        public ClientRepository()
        {
            _context = HC.GetC();
        }
        public Client[] GetClients()
        {
            return _context.Clients.ToArray();
        }
        public Client? GetClient(int id)
        {
            return _context.Clients.FirstOrDefault(c => c.Id == id);
        }
    }
}
