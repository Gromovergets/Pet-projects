﻿using ServiceDLl.Context;
using ServiceDLl.Models.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Repository
{
    public class StatusRepository
    {
        private ServiceContext _context { get; set; }
        public StatusRepository() 
        {
            _context = HC.GetC();
            
        }
        public Status[] GetStatuses()
        {
            return _context.Statuses.ToArray();
        }
        public Status? GetStatus(int id)
        {
            return _context.Statuses.Where(x => x.Id == id).FirstOrDefault();

        }
    }
}
