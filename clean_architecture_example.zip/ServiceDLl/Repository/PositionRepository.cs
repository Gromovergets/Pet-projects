﻿using ServiceDLl.Context;
using ServiceDLl.Models.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Repository
{
    public class PositionRepository
    {
        private ServiceContext _context { get; set; }   
        public PositionRepository() 
        {
            _context = HC.GetC();
        }
        public Position? GetPosition(int id)
        {
            return _context.Positions.FirstOrDefault(x => x.Id == id); 
        }
    }
}
