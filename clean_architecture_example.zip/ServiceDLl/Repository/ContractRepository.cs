﻿using ServiceDLl.Context;
using ServiceDLl.Models.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Repository
{
    public class ContractRepository
    {
        private ServiceContext _context { get; set; }
        public ContractRepository()
        {
            _context = HC.GetC();
        }
        public void AddContract(Contract contract)
        {
            _context.Contracts.Add(contract);
        }
        public Contract[] GetContracts()
        {
            return _context.Contracts.ToArray();
        }
        public void Finish(int id)
        {
            _context.Contracts.FirstOrDefault(x=>x.Id == id).Date_finish=DateTime.Now;
        }
        public Contract? GetContract(int id)
        {
            return _context.Contracts.FirstOrDefault(x=>x.Id==id);
        }
        public void ChangeStatusLog(int id_con, int id_stat)
        {
            _context.LoggingContracts.Add(new LoggingContract
            {
                id_contract = id_con,
                IdType = id_stat,
                Date = DateTime.Now
            });
        }
        public LoggingContract[] GetLoggs()
        {
            return _context.LoggingContracts.ToArray();
        }
        public void DeleteLog(int id)
        {
            _context.LoggingContracts.Remove(_context.LoggingContracts.FirstOrDefault(x => x.Id == id));
        }
    }
}
