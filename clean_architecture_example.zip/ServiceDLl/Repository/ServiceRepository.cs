﻿using ServiceDLl.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Repository
{
    public class ServiceRepository
    {
        private ServiceContext _context { get; set; }
        public ServiceRepository()
        {
            _context = HC.GetC();
        }
        public Models.DB.Service? GetService(int id)
        {
           return _context.Services.FirstOrDefault(s => s.Id == id);
        }
        public Models.DB.Service[] GetServices()
        {
            return _context.Services.ToArray();
        }
    }
}
