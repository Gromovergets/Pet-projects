﻿using ServiceDLl.Models.DB;
using ServiceDLl.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Service
{
    public class StatusService
    {
        private StatusRepository statusRepository { get; set; }
        public StatusService()
        {
            statusRepository = new StatusRepository();
        }
        public Status? GetStatus(int? id)
        {
            
            return statusRepository.GetStatus((int)id);
        }
    }
}
