﻿using ServiceDLl.Models.DB;
using ServiceDLl.Models.Domains;
using ServiceDLl.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Service
{
    public class AuthService
    {
        public Auth AuthEmployee(string login, string passsword)
        {
            Auth u = new Auth();
            EmployeeRepository repository = new EmployeeRepository();
            Employee? user = repository.GetUser(login, passsword);
            if (user != null)
            {
                u.user = user;
                u.IsSuccess = true;
                u.error = null;

            }
            else
            {

                u.user = null;
                u.IsSuccess = false;
                u.error = "Неверный логин или пароль";
               
            }
            return u;
            

        }
    }
}
