﻿
using ServiceDLl.Models.DB;
using ServiceDLl.Models.Domains;
using ServiceDLl.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace ServiceDLl.Service
{
    public class ClientService
    {
        private ClientRepository _rep;
        public ClientService()
        {
            _rep = new ClientRepository();
        }
        public Client[] GetClients(String? sort="sort")
        {
            List<Client> list = _rep.GetClients().ToList();
            if (sort == "sort")
            {
                list.Sort((p1, p2) => p1.Surname.CompareTo(p2.Surname));
            }
            else if(sort =="reverse")
            {
                list.Sort((p1, p2) => p2.Surname.CompareTo(p1.Surname));
            }
           
           
            return list.ToArray();
        }
        public object? GetClient(int id,string? type = null)
        {
            if (type == "db")
            {
                return _rep.GetClient(id);
            }
            else if (type == "domain")
            {
                return new ClientDomain(_rep.GetClient(id));
            }
            return null;
        }
    }
}
