﻿using ServiceDLl.Context;
using ServiceDLl.Models.DB;
using ServiceDLl.Models.Domains;
using ServiceDLl.Repository;
using System;
using System.Collections.Generic;

using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Service
{
    public class ContractService
    {
        private ContractRepository contractRepository {  get; set; }  
        
        public ContractService()
        {
            contractRepository = new ContractRepository();
        }
        public ContractDomain[] GetContracts(String? sort="sort")
        {
            List<Contract> list = contractRepository.GetContracts().ToList();
            if (sort == "sort")
            {
                list.Sort((p1, p2) => p1.Device.CompareTo(p2.Device));
            }
            else if (sort == "reverse")
            {
                list.Sort((p1, p2) => p2.Device.CompareTo(p1.Device));
            }
            return list.Select(x=>new ContractDomain(x)).ToArray();
        }
        public void Change(int id,string param,string value)
        {
            var contr=contractRepository.GetContract(id);
            switch (param)
            {
                case "status":
                    {
                        try
                        {
                            contr.IdStatus = Convert.ToInt32(value);
                       
                        }
                        catch(Exception ex) { }
                        break;

                    }
                case "device":
                    {
                        contr.Device = value.ToString();
                        break;
                    }
            }
          
          
        }
        public LoggingContractDomain[] GetLogging()
        {
            return contractRepository.GetLoggs().Select(x=>new  LoggingContractDomain(x)).ToArray();    
        }
    }
}
