﻿using ServiceDLl.Models.Domains;
using ServiceDLl.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Service
{
    public  class ServiceService
    {
        private ServiceRepository _rep { get; set; }
        public ServiceService()
        { 
            _rep = new ServiceRepository();
        }
        public ServiceDomain[] GetServices()
        {
             ServiceDomain[] list=_rep.GetServices().Select(x=>new ServiceDomain(x.Id)).ToArray();
            return list;
        }
    }
}
