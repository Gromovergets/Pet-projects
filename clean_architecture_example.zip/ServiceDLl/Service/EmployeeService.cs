﻿using ServiceDLl.Models.Domains;
using ServiceDLl.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Service
{
   public class EmployeeService
    {
        private EmployeeRepository _repository { get; set; }
        public EmployeeService() 
        { 
            _repository = new EmployeeRepository(); 
        }
        public EmployeeDomain[] GetIngneers()
        {
            var list =_repository.GetEmployees().Select(x=>new EmployeeDomain(x)).Where(x=>x.IdPosition==1).ToArray();
            return list;
            
        }
        public EmployeeDomain[] GetEmployeers()
        {
            return _repository.GetEmployees().Select(x=>new EmployeeDomain(x)).ToArray();
        }
        public EmployeeDomain? GetEmployee(int id)
        {
            return new EmployeeDomain(_repository.GetEmployees().FirstOrDefault(x=>x.Id==id));
        }
    }
}
