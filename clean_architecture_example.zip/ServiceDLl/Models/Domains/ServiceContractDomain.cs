﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Models.Domains
{
    public class ServiceContractDomain
    {
        public int Id { get; set; }

        public int? IdService { get; set; }

        public int? IdContract { get; set; }

        public string? NameService { get; set; }    


    }
}
