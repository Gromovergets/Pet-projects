﻿using ServiceDLl.Models.DB;
using ServiceDLl.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Models.Domains
{
    public class LoggingContractDomain
    {
        public int Id { get; set; }

        public int? IdType { get; set; }

        public DateTime? Date { get; set; }

        public int? id_contract { get; set; }



        public string infostatusinfo { get; set; }

        public LoggingContractDomain(LoggingContract log) 
        { 
            Id = log.Id;
            IdType = log.IdType;
            Date = log.Date.Value.Date;
            id_contract = log.id_contract;
            infostatusinfo ="Статус заказа был изменен на <"+new StatusRepository().GetStatus((int)IdType).Name+">";
        }
        public LoggingContractDomain()
        {
           
        }
    }
}
