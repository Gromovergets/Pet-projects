﻿using ServiceDLl.Models.DB;
using ServiceDLl.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Models.Domains
{
    public class ContractDomain
    {
        private ClientService clientService { get; set; }

        private StatusService statusService { get; set; }

        public int Id { get; set; }

        public string? DateCreate { get; set; }

        public string? Device { get; set; }

        public string? Crash { get; set; }

        public DateTime? crdate { get; set; }

        public DateTime? date_finish { get; set; }

        public string? DescriptionCrash { get; set; }

        public ClientDomain? Client { get; set; }

        public Status Status { get; set; }

        public ContractDomain(Contract contract) 
        {
            clientService = new ClientService();
            statusService=new StatusService();
            Id=contract.Id;
            DateCreate=contract.DateCreate.Value.ToShortDateString();
            Device=contract.Device;
            Crash=contract.Crash;
            crdate = contract.DateCreate;
            date_finish = contract.Date_finish;
            DescriptionCrash=contract.DescriptionCrash;
            Client = (ClientDomain)clientService.GetClient(contract.Id,"domain");
            Status = statusService.GetStatus(contract.IdStatus);
        }
        public ContractDomain() { }
    }
}
