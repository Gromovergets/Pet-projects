﻿using ServiceDLl.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Models.Domains
{
    public  class EquipmentDomain
    {
        public int Id { get; set; }

        public string? Name { get; set; }

        public EquipmentDomain(int id)
        {
            var equip = new EquipmentRepository().GetEquipment(id);
            Id = equip.Id;
            Name=equip.Name;
        }
        public EquipmentDomain()
        {}
    }
}
