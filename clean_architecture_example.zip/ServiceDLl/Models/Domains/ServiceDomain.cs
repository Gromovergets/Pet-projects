﻿using ServiceDLl.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Models.Domains
{
    public class ServiceDomain
    {
        public int Id { get; set; }

        public string? Name { get; set; }

        public int? Count { get; set; }
        private ServiceRepository? _rep { get; set; }    
        public ServiceDomain(int id)
        {
            _rep = new ServiceRepository();
            Id = id;
            var ser=_rep.GetService(id);
            Name = ser.Name;
            Count = ser.Count;
        }
        public ServiceDomain() { }

    }
}
