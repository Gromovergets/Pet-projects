﻿using ServiceDLl.Models.DB;
using ServiceDLl.Repository;
using ServiceDLl.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Models.Domains
{
    public class EmployeeDomain
    {
        private StatusService? _service { get; set; }
        public int Id { get; set; }

        public string? FirstName { get; set; }

        public string? LastName { get; set; }

        public string? Surname { get; set; }
        public int? IdPosition { get; set; }

        public string? NamePosition { get; set; }

        public string? FullName {get;set;}
        private EmployeeService? _serviceemp { get; set; }

        public EmployeeDomain(Employee employee) 
        {
            _service=new StatusService();


            Id=employee.Id;
            FirstName=employee.FirstName;
            LastName=employee.LastName;
            Surname=employee.Surname;
            IdPosition=employee.IdPosition;
            NamePosition = _service.GetStatus(employee.IdPosition).Name;
            FullName = LastName + " " + FirstName[0] + "." + Surname[0] + ".";

        }
        public EmployeeDomain(int? id)
        {
            _serviceemp = new EmployeeService();
           
            var employee=_serviceemp.GetEmployee((int)id);
            Id = employee.Id;
            FirstName = employee.FirstName;
            LastName = employee.LastName;
            Surname = employee.Surname;
            IdPosition = employee.IdPosition;
            NamePosition = new PositionRepository().GetPosition((int)employee.IdPosition).Name;
            FullName = LastName + " " + FirstName[0] + "." + Surname[0] + ".";
        }
        public EmployeeDomain()
        { }
        

    }
}
