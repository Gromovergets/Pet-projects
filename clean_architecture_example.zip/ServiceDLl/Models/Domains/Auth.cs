﻿
using ServiceDLl.Models.DB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Models.Domains
{
    public class Auth
    {
        public Employee? user { get; set; }
        public bool IsSuccess { get; set; }
         public string? error { get; set; }
    }
}
