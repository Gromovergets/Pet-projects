﻿using System;
using System.Collections.Generic;

namespace ServiceDLl.Models.DB;

public partial class EquipmentContract
{
    public int Id { get; set; }

    public int? IdEquipment { get; set; }

    public int? IdContract { get; set; }

    public virtual Contract? IdContractNavigation { get; set; }

    public virtual Equipment? IdEquipmentNavigation { get; set; }
}
