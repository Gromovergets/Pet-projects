﻿using System;
using System.Collections.Generic;

namespace ServiceDLl.Models.DB;

public partial class Employee
{
    public int Id { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string? Surname { get; set; }

    public int? IdPosition { get; set; }

    public string? Login { get; set; }

    public string? Password { get; set; }

    public virtual ICollection<Contract> Contracts { get; set; } = new List<Contract>();

    public virtual ICollection<EmployeeContract> EmployeeContracts { get; set; } = new List<EmployeeContract>();

    public virtual Position? IdPositionNavigation { get; set; }
}
