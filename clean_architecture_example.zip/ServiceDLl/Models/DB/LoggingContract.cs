﻿using System;
using System.Collections.Generic;

namespace ServiceDLl.Models.DB;

public partial class LoggingContract
{
    public int Id { get; set; }

    public int? IdType { get; set; }

    public DateTime? Date { get; set; }

    public int? id_contract { get; set; }

    public virtual Status? IdTypeNavigation { get; set; }
}
