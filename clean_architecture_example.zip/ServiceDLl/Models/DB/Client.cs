﻿using System;
using System.Collections.Generic;

namespace ServiceDLl.Models.DB;

public partial class Client
{
    public int Id { get; set; }

    public string? FirstName { get; set; }

    public string? LastName { get; set; }

    public string? Surname { get; set; }

    public virtual ICollection<Contract> Contracts { get; set; } = new List<Contract>();
}
