﻿using System;
using System.Collections.Generic;

namespace ServiceDLl.Models.DB;

public partial class ServiceContracty
{
    public int Id { get; set; }

    public int? IdService { get; set; }

    public int? IdContract { get; set; }

    public virtual Contract? IdContractNavigation { get; set; }

    public virtual Service? IdServiceNavigation { get; set; }
}
