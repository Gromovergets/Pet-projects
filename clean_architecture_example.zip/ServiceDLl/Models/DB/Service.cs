﻿using System;
using System.Collections.Generic;

namespace ServiceDLl.Models.DB;

public partial class Service
{
    public int Id { get; set; }

    public string? Name { get; set; }

    public int? Count { get; set; }

    public virtual ICollection<ServiceContracty> ServiceContracties { get; set; } = new List<ServiceContracty>();
}
