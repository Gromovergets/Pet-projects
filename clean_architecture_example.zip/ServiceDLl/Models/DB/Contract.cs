﻿using System;
using System.Collections.Generic;

namespace ServiceDLl.Models.DB;

public partial class Contract
{
    public int Id { get; set; }

    public DateTime? DateCreate { get; set; }

    public string? Device { get; set; }

    public string? Crash { get; set; }

    public string? DescriptionCrash { get; set; }

    public int? IdClient { get; set; }

    public int? IdStatus { get; set; }

    public int? IdEmployee { get; set; }

    public DateTime? Date_finish { get; set; }

    public virtual ICollection<EmployeeContract> EmployeeContracts { get; set; } = new List<EmployeeContract>();

    public virtual ICollection<EquipmentContract> EquipmentContracts { get; set; } = new List<EquipmentContract>();

    public virtual Client? IdClientNavigation { get; set; }

    public virtual Employee? IdEmployeeNavigation { get; set; }

    public virtual Status? IdStatusNavigation { get; set; }

    public virtual ICollection<ServiceContracty> ServiceContracties { get; set; } = new List<ServiceContracty>();
}
