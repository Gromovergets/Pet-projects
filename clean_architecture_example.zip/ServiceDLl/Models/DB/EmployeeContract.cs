﻿using System;
using System.Collections.Generic;

namespace ServiceDLl.Models.DB;

public partial class EmployeeContract
{
    public int Id { get; set; }

    public int? IdEmployee { get; set; }

    public int? IdContract { get; set; }

    public virtual Contract? IdContractNavigation { get; set; }

    public virtual Employee? IdEmployeeNavigation { get; set; }
}
