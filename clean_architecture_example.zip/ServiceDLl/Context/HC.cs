﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ServiceDLl.Context
{
    public static class HC
    {
        private static ServiceContext _context;
        public static ServiceContext GetC()
        {
            if (_context == null)
            {
                _context = new ServiceContext();
            }
            return _context;
        }
    }
}
