﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using ServiceDLl.Models.DB;

namespace ServiceDLl.Context;

public partial class ServiceContext : DbContext
{
    public ServiceContext()
    {
    }

    public ServiceContext(DbContextOptions<ServiceContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Client> Clients { get; set; }

    public virtual DbSet<Contract> Contracts { get; set; }

    public virtual DbSet<Employee> Employees { get; set; }

    public virtual DbSet<EmployeeContract> EmployeeContracts { get; set; }

    public virtual DbSet<Equipment> Equipment { get; set; }

    public virtual DbSet<EquipmentContract> EquipmentContracts { get; set; }

    public virtual DbSet<LoggingContract> LoggingContracts { get; set; }

    public virtual DbSet<Position> Positions { get; set; }

    public virtual DbSet<Models.DB.Service> Services { get; set; }

    public virtual DbSet<ServiceContracty> ServiceContracties { get; set; }

    public virtual DbSet<Status> Statuses { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see https://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=LAPTOP-KLBSCP3I\\SQLEXPRESS;Initial Catalog=Service;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=True;Application Intent=ReadWrite;Multi Subnet Failover=False");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Client>(entity =>
        {
            entity.ToTable("Client");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.FirstName).HasMaxLength(50);
            entity.Property(e => e.LastName).HasMaxLength(50);
            entity.Property(e => e.Surname).HasMaxLength(50);
        });

        modelBuilder.Entity<Contract>(entity =>
        {
            entity.ToTable("Contract");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Crash)
                .HasMaxLength(50)
                .HasColumnName("crash");
            entity.Property(e => e.DateCreate)
                .HasColumnType("datetime")
                .HasColumnName("date_create");
            entity.Property(e => e.DescriptionCrash)
                .HasMaxLength(150)
                .HasColumnName("description_crash");
            entity.Property(e => e.Device)
                .HasMaxLength(50)
                .HasColumnName("device");
            entity.Property(e => e.IdClient).HasColumnName("id_client");
            entity.Property(e => e.IdEmployee).HasColumnName("id_employee");
            entity.Property(e => e.IdStatus).HasColumnName("id_status");

            entity.HasOne(d => d.IdClientNavigation).WithMany(p => p.Contracts)
                .HasForeignKey(d => d.IdClient)
                .HasConstraintName("FK_Contract_Client");

            entity.HasOne(d => d.IdEmployeeNavigation).WithMany(p => p.Contracts)
                .HasForeignKey(d => d.IdEmployee)
                .HasConstraintName("FK_Contract_Employee");

            entity.HasOne(d => d.IdStatusNavigation).WithMany(p => p.Contracts)
                .HasForeignKey(d => d.IdStatus)
                .HasConstraintName("FK_Contract_Status");
        });

        modelBuilder.Entity<Employee>(entity =>
        {
            entity.ToTable("Employee");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.FirstName).HasMaxLength(50);
            entity.Property(e => e.IdPosition).HasColumnName("id_position");
            entity.Property(e => e.LastName).HasMaxLength(50);
            entity.Property(e => e.Login)
                .HasMaxLength(50)
                .HasColumnName("login");
            entity.Property(e => e.Password)
                .HasMaxLength(50)
                .HasColumnName("password");
            entity.Property(e => e.Surname).HasMaxLength(50);

            entity.HasOne(d => d.IdPositionNavigation).WithMany(p => p.Employees)
                .HasForeignKey(d => d.IdPosition)
                .HasConstraintName("FK_Employee_Position");
        });

        modelBuilder.Entity<EmployeeContract>(entity =>
        {
            entity.ToTable("EmployeeContract");

            entity.HasOne(d => d.IdContractNavigation).WithMany(p => p.EmployeeContracts)
                .HasForeignKey(d => d.IdContract)
                .HasConstraintName("FK_EmployeeContract_Contract");

            entity.HasOne(d => d.IdEmployeeNavigation).WithMany(p => p.EmployeeContracts)
                .HasForeignKey(d => d.IdEmployee)
                .HasConstraintName("FK_EmployeeContract_Employee");
        });

        modelBuilder.Entity<Equipment>(entity =>
        {
            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .HasColumnName("name");
        });

        modelBuilder.Entity<EquipmentContract>(entity =>
        {
            entity.ToTable("Equipment_Contract");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.IdContract).HasColumnName("id_contract");
            entity.Property(e => e.IdEquipment).HasColumnName("id_equipment");

            entity.HasOne(d => d.IdContractNavigation).WithMany(p => p.EquipmentContracts)
                .HasForeignKey(d => d.IdContract)
                .HasConstraintName("FK_Equipment_Contract_Contract");

            entity.HasOne(d => d.IdEquipmentNavigation).WithMany(p => p.EquipmentContracts)
                .HasForeignKey(d => d.IdEquipment)
                .HasConstraintName("FK_Equipment_Contract_Equipment");
        });

        modelBuilder.Entity<LoggingContract>(entity =>
        {
            entity.ToTable("Logging_Contract");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.Date)
                .HasColumnType("datetime")
                .HasColumnName("date");
            entity.Property(e => e.IdType).HasColumnName("id_type");

            entity.HasOne(d => d.IdTypeNavigation).WithMany(p => p.LoggingContracts)
                .HasForeignKey(d => d.IdType)
                .HasConstraintName("FK_Logging_Contract_Status");
        });

        modelBuilder.Entity<Position>(entity =>
        {
            entity.ToTable("Position");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .HasColumnName("name");
        });

        modelBuilder.Entity<Models.DB.Service>(entity =>
        {
            entity.ToTable("Service");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Count).HasColumnName("count");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .HasColumnName("name");
        });

        modelBuilder.Entity<ServiceContracty>(entity =>
        {
            entity.ToTable("Service_Contracty");

            entity.Property(e => e.Id).HasColumnName("id");
            entity.Property(e => e.IdContract).HasColumnName("id_contract");
            entity.Property(e => e.IdService).HasColumnName("id_service");

            entity.HasOne(d => d.IdContractNavigation).WithMany(p => p.ServiceContracties)
                .HasForeignKey(d => d.IdContract)
                .HasConstraintName("FK_Service_Contracty_Contract");

            entity.HasOne(d => d.IdServiceNavigation).WithMany(p => p.ServiceContracties)
                .HasForeignKey(d => d.IdService)
                .HasConstraintName("FK_Service_Contracty_Service");
        });

        modelBuilder.Entity<Status>(entity =>
        {
            entity.ToTable("Status");

            entity.Property(e => e.Id)
                .ValueGeneratedNever()
                .HasColumnName("id");
            entity.Property(e => e.Name)
                .HasMaxLength(50)
                .HasColumnName("name");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
